/*
var scores=[34,56,87,98]

for(var score of scores){

    console.log(score)

}

let colors=['red','white','green']

for(var [index,color] of colors.entries()){


    console.log(index,':',color)

}
*/

