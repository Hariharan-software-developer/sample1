//looping statemens are used to control the flow of statement
//for loop



/*
var a='hello world'


for(var i=0;i<=10;i++){

    console.log(a)

}
*/

var num=[1,2,3,4,5,6]
var squaredarr=[]

for(var i=0;i<num.length;i++){
    squaredarr.push(num[i]*num[i])
    

}
console.log(squaredarr)