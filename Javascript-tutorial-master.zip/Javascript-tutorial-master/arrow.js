let test1=()=>{
    console.log(1)
}
let test2=a=>{

    console.log(a+3)

}
let test3=(a,b)=>{

    console.log(a*b)

}
test1()
test2(3)
test3(3,4)
