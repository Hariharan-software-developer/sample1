var a=20

console.log(a)
var greet='hello'
console.log(greet)
