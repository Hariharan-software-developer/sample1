//setTimeout(cb,2000)

function greet(){

    console.log('hello from the settimeout')


}

setTimeout(greet,3000)

console.log('after the set timeout')


