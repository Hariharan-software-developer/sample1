
//we are using backticks so called key in js es6 this works like a formated string in python

console.log(`scaler
 is 
 awesome`)

 let a=21

 console.log(`My age is ${a}`)


