class dog{

    sound(){
        console.log('dog barks....ow ow ow')
    }
}
class cat{

    sound(){

        console.log('cat mews meow meow')

    }
}

let nari=new dog()
let mena=new cat()

nari.sound()
mena.sound()

