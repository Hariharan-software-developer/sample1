var arr=[1,'levin',true]


console.log(arr)
//access the array elements
var a=arr[0]
console.log(arr[2])
//replacing the values in arrays

arr[0]=2
console.log(arr)
//finding length

var len=arr.length
console.log(len)
//js array methods
var arr2=[12,13,4,15]

arr2.pop()

arr2.push(100)

console.log(arr2)
//Shift method to remove first element
console.log("shifted value is: ",arr2.shift())
console.log(arr2)
//unshift 
arr2.unshift(12)
console.log(arr2)







