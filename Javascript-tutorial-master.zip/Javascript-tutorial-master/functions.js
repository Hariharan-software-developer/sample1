function greet(){


    console.log("hello world")

}
greet()


//parameters and arguments

function add(a,b){


    console.log(a+b)
}

add(2,3)
add(5,6)
add(89,45)



