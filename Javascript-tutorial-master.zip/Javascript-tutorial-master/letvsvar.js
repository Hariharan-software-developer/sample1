
//let keyword is block scoped no one can access the variable inside the if block 
//and we cant be able to re define the variable with the same name


if(true){


    let a=10
    console.log(a)
}
console.log(a)


//const

const a=20
a=30




console.log(a)




