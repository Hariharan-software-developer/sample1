var i=1
var n=10
while(i<=10){


    console.log(i)
    i++

}