//it is pure function

let add=(x,a)=>{

   return x+a 
   
}
console.log(add(2,3))



