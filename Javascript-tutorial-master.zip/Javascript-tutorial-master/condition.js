/*
var myscore=85

if(myscore>90){
    console.log('you got a bicycle')


}

else{

    console.log('get better mark next time')

}
*/
//else if

var mark=45

if(mark>=90){

    console.log('Grade:A')
}
else if(mark>=70 && mark<=89){
    console.log('Grade: B')
}
else if(mark>=50 && mark<=69){

    console.log('Grade : C')

}
else{
    console.log('Better go and studdy for the next exam')
}




