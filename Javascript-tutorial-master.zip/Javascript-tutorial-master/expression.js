//annonymus function
var add=function(a,b){


    return a+b


}
var result=add(6,7)
console.log(result)

