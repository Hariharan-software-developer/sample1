var colors={
    primary:'blue',
    secondary:'Red',
    third:'white'
}


for(var color in colors){


    console.log(color,':',colors[color])
}


