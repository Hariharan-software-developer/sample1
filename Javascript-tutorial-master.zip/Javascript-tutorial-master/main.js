let calculator=require('./calci')




calculator.addition(3,4)

calculator.subraction(3,4)

calculator.multiple(3,4)

calculator.division(3,4)
