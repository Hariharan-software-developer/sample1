let number=[1,2,20,30,12,50]
let even=number.filter(function(n){

    return n%2==0


})

console.log(even)


let trans=[100,300,400,600,-900,700]

let pos=trans.filter(function(n){

    return n>0
})
console.log(pos)


let arr1=[1,2,3,4,5,6,7,8,9]

let odd=arr1.filter(function(n){

    return n%2!==0
})
console.log(odd)

    


